In order to run the code open 'Assignment3.ipynb' in Google Colab.
*** Note: The value of accuracy may differ slightly when you run the 
	code by yourself.