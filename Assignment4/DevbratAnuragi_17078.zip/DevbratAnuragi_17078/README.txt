
I have written my report alongwith the code in google colab notebook.
I have answered every question in the report itself.

Report	:-DevbratAnuragi_17078.pdf
Code	:-DevbratAnuragi_17078.ipynb

In order to run the code just upload the code to google colab and 
upload the given file.

Note: for CNN you have to upload the decompressed file which I have 
downloaded fron the link given in the assignmnet.