I have written my code as well as report in colab notebook therefore
DevbratAnuragi_17078.pdf contains both of my code and report.
TO run the code upload DevbratAnuragi_17078.ipynb to google colab
and run directly
